import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'path';

export default defineConfig({
  plugins: [react()],
  build: {
    emptyOutDir: false,
    target: 'es2020',
    minify: false,
    rollupOptions: {
      input: {
        ui: resolve(__dirname, 'src/ui/main.tsx'),
      },
      output: {
        dir: 'dist',
        entryFileNames: 'ui.js',
        assetFileNames: (assetInfo) => {
          if (assetInfo.name && assetInfo.name.endsWith('.css')) {
            return 'ui.css';
          }
          return 'assets/[name].[ext]';
        },
      },
    },
    cssCodeSplit: false,
  },
});