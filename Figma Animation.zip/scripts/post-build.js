const fs = require('fs');
const path = require('path');

const distDir = path.resolve(__dirname, '../dist');
const jsContent = fs.readFileSync(path.join(distDir, 'ui.js'), 'utf-8');
const cssContent = fs.readFileSync(path.join(distDir, 'ui.css'), 'utf-8');

const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Figma Animate</title>
  <style>${cssContent}</style>
</head>
<body>
  <div id="root"></div>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      ${jsContent.replace(/<\/script>/gi, '<\\/script>')}
    });
  </script>
</body>
</html>`;

fs.writeFileSync(path.join(distDir, 'ui.html'), html);
fs.unlinkSync(path.join(distDir, 'ui.js'));
fs.unlinkSync(path.join(distDir, 'ui.css'));

console.log('✅ Build complete!');