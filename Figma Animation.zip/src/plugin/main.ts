import type { PluginMessage, UIMessage, FrameAnimationData, LayerData, AnimationConfig, ExportFormat } from '../core/types';

const PLUGIN_KEY = 'figma_animate';
const DATA_KEY = 'animation';

function isExportableNode(node: SceneNode): boolean {
  return node.type === 'RECTANGLE' 
    || node.type === 'ELLIPSE' 
    || node.type === 'VECTOR'
    || node.type === 'STAR'
    || node.type === 'LINE'
    || node.type === 'POLYGON'
    || node.type === 'TEXT'
    || node.type === 'FRAME'
    || node.type === 'GROUP'
    || node.type === 'COMPONENT'
    || node.type === 'INSTANCE'
    || node.type === 'SHAPE_WITH_TEXT'
    || node.type === 'CONNECTOR';
}

function determineExportFormat(node: SceneNode): ExportFormat {
  if (node.type === 'VECTOR' || node.type === 'STAR' || node.type === 'POLYGON' || node.type === 'LINE') {
    return 'svg';
  }
  if (node.type === 'TEXT') {
    return 'png';
  }
  if ('fills' in node && Array.isArray(node.fills)) {
    const fills = node.fills as Paint[];
    for (const fill of fills) {
      if (fill.type === 'SOLID' && fill.opacity !== undefined && fill.opacity < 1) {
        return 'png';
      }
      if (fill.type === 'IMAGE') {
        return 'jpg';
      }
    }
  }
  if ('opacity' in node && node.opacity !== undefined && node.opacity < 1) {
    return 'png';
  }
  return 'png';
}

function scanNode(node: SceneNode, zIndex: number): LayerData | null {
  if (!isExportableNode(node)) return null;

  const position = {
    x: node.x, y: node.y,
    width: node.width, height: node.height,
  };

  const savedData = node.getSharedPluginData(PLUGIN_KEY, DATA_KEY);
  let savedIn: AnimationConfig | undefined;
  let savedOut: AnimationConfig | undefined;

  if (savedData) {
    try {
      const parsed = JSON.parse(savedData);
      savedIn = parsed.in;
      savedOut = parsed.out;
    } catch {}
  }

  return {
    nodeId: node.id,
    name: node.name,
    type: node.type as LayerData['type'],
    exportFormat: determineExportFormat(node),
    position, zIndex,
    opacity: 'opacity' in node ? (node.opacity ?? 1) : 1,
    visible: node.visible,
    in: savedIn,
    out: savedOut,
  };
}

function scanFrame(frame: FrameNode): FrameAnimationData {
  const layers: LayerData[] = [];
  let zIndex = 0;

  for (const child of frame.children) {
    const layer = scanNode(child, zIndex++);
    if (layer) layers.push(layer);
  }

  const frameData = frame.getSharedPluginData(PLUGIN_KEY, DATA_KEY);
  let timeline = { duration: 10, loop: false };

  if (frameData) {
    try {
      const parsed = JSON.parse(frameData);
      if (parsed.timeline) timeline = parsed.timeline;
      if (parsed.layers) {
        for (const savedLayer of parsed.layers) {
          const existing = layers.find(l => l.nodeId === savedLayer.nodeId);
          if (existing) {
            existing.in = savedLayer.in;
            existing.out = savedLayer.out;
          }
        }
      }
    } catch {}
  }

  return {
    version: '1.0',
    frameId: frame.id,
    frameName: frame.name,
    timeline,
    layers,
  };
}

async function handleScanFrame(frameId: string): Promise<void> {
  const frame = figma.getNodeById(frameId) as FrameNode | null;
  if (!frame || frame.type !== 'FRAME') {
    figma.ui.postMessage({ type: 'error', message: 'Frame not found' } as UIMessage);
    return;
  }
  const data = scanFrame(frame);
  figma.ui.postMessage({ type: 'frame-scanned', data } as UIMessage);
}

async function handleSaveAnimation(data: FrameAnimationData): Promise<void> {
  const frame = figma.getNodeById(data.frameId) as FrameNode | null;
  if (!frame || frame.type !== 'FRAME') {
    figma.ui.postMessage({ type: 'error', message: 'Frame not found' } as UIMessage);
    return;
  }

  frame.setSharedPluginData(PLUGIN_KEY, DATA_KEY, JSON.stringify({
    timeline: data.timeline,
    layers: data.layers.map(l => ({
      nodeId: l.nodeId,
      in: l.in,
      out: l.out,
    })),
  }));

  for (const layer of data.layers) {
    const node = figma.getNodeById(layer.nodeId);
    if (node) {
      node.setSharedPluginData(PLUGIN_KEY, DATA_KEY, JSON.stringify({
        in: layer.in,
        out: layer.out,
      }));
    }
  }

  figma.ui.postMessage({ type: 'animation-saved', success: true } as UIMessage);
}

async function handleLoadAnimation(frameId: string): Promise<void> {
  const frame = figma.getNodeById(frameId) as FrameNode | null;
  if (!frame || frame.type !== 'FRAME') {
    figma.ui.postMessage({ type: 'animation-loaded', data: null } as UIMessage);
    return;
  }
  const data = scanFrame(frame);
  figma.ui.postMessage({ type: 'animation-loaded', data } as UIMessage);
}

async function handleExportAssets(layerIds: string[], format: ExportFormat): Promise<void> {
  const assets: { nodeId: string; name: string; format: ExportFormat; bytes: Uint8Array }[] = [];

  for (const layerId of layerIds) {
    const node = figma.getNodeById(layerId);
    if (!node || !isExportableNode(node)) continue;

    const figmaFormat = format === 'jpg' ? 'JPG' : format === 'svg' ? 'SVG' : 'PNG';
    
    try {
      const bytes = await node.exportAsync({
        format: figmaFormat,
        constraint: { type: 'SCALE', value: 2 },
      });

      assets.push({
        nodeId: layerId,
        name: node.name.replace(/[^a-zA-Z0-9_-]/g, '_'),
        format,
        bytes,
      });
    } catch (err) {
      console.error(`Failed to export ${layerId}:`, err);
    }
  }

  figma.ui.postMessage({ type: 'assets-exported', assets } as UIMessage);
}

figma.showUI(__html__, { width: 900, height: 700 });

figma.ui.onmessage = async (msg: PluginMessage) => {
  console.log('Plugin received message:', msg.type, msg);
  
  switch (msg.type) {
    case 'init':
      const selection = figma.currentPage.selection;
      if (selection.length === 1 && selection[0].type === 'FRAME') {
        await handleScanFrame(selection[0].id);
      } else {
        figma.ui.postMessage({ 
          type: 'error', 
          message: 'Please select a single frame to animate' 
        } as UIMessage);
      }
      break;
    case 'resize-window':
      figma.ui.resize(msg.width, msg.height);
      break;
    case 'scan-frame':
      await handleScanFrame(msg.frameId);
      break;
    case 'save-animation':
      await handleSaveAnimation(msg.data);
      break;
    case 'load-animation':
      await handleLoadAnimation(msg.frameId);
      break;
    case 'export-assets':
      await handleExportAssets(msg.layerIds, msg.format);
      break;
    default:
      console.log('Unknown message:', msg);
  }
};