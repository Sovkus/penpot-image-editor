import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/ui.css';

const rootEl = document.getElementById('root');
if (!rootEl) {
  document.body.innerHTML = '<div style="color:red;padding:20px;">ERROR: root not found</div>';
} else {
  try {
    const root = ReactDOM.createRoot(rootEl);
    root.render(
      <React.StrictMode>
        <App />
      </React.StrictMode>
    );
  } catch(e) {
    rootEl.innerHTML = '<div style="color:red;padding:20px;">React error: ' + (e as Error).message + '</div>';
  }
}