import React, { useState, useEffect, useCallback } from 'react';
import type { FrameAnimationData, UIMessage } from '../core/types';
import { LayerList } from './components/LayerList/LayerList';
import { Timeline } from './components/Timeline/Timeline';
import { Preview } from './components/Preview/Preview';
import './styles/ui.css';

const WINDOW_SIZES = {
  small: { width: 700, height: 500, label: 'Small Window' },
  default: { width: 900, height: 600, label: 'Default Window' },
  large: { width: 1200, height: 800, label: 'Large Window' },
};

const App: React.FC = () => {
  const [animationData, setAnimationData] = useState<FrameAnimationData | null>(null);
  const [selectedLayerId, setSelectedLayerId] = useState<string | null>(null);
  const [windowSize, setWindowSize] = useState<keyof typeof WINDOW_SIZES>('default');
  const [isPlaying, setIsPlaying] = useState(false);
  const [previewStartTime, setPreviewStartTime] = useState(0);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      const msg = event.data.pluginMessage as UIMessage;
      if (!msg) return;
      
      switch (msg.type) {
        case 'frame-scanned':
        case 'animation-loaded':
          setAnimationData(msg.data);
          break;
        case 'error':
          console.error(msg.message);
          break;
      }
    };

    window.addEventListener('message', handleMessage);
    parent.postMessage({ pluginMessage: { type: 'init' } }, '*');
    
    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, []);

  const handleWindowSizeChange = useCallback((size: keyof typeof WINDOW_SIZES) => {
    setWindowSize(size);
    const { width, height } = WINDOW_SIZES[size];
    parent.postMessage({ pluginMessage: { type: 'resize-window', width, height } }, '*');
  }, []);

  const handlePlay = useCallback(() => setIsPlaying(true), []);
  const handlePause = useCallback(() => setIsPlaying(false), []);
  const handleScrubberChange = useCallback((time: number) => {
    setPreviewStartTime(time);
    setIsPlaying(true);
  }, []);

  if (!animationData) {
    return (
      <div className="app-loading">
        <div className="loading-spinner" />
        <p>Scanning frame...</p>
      </div>
    );
  }

  return (
    <div className="app">
      {/* Toolbar */}
      <div className="toolbar">
        <div className="toolbar-left">
          <span className="toolbar-title">Figma Animate</span>
        </div>
        <div className="toolbar-right">
          <select 
            className="window-size-select"
            value={windowSize}
            onChange={(e) => handleWindowSizeChange(e.target.value as keyof typeof WINDOW_SIZES)}
          >
            {Object.entries(WINDOW_SIZES).map(([key, { label }]) => (
              <option key={key} value={key}>{label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Content */}
      <div className="main-content">
        {/* Left: Timeline + Layers */}
        <div className="left-panel">
          <Timeline
            timeline={animationData.timeline}
            layers={animationData.layers}
            selectedLayerId={selectedLayerId}
            onTimelineChange={() => {}}
            onLayerAnimationChange={() => {}}
            onScrubberChange={handleScrubberChange}
            isPlaying={isPlaying}
            onPlay={handlePlay}
            onPause={handlePause}
          />
          <LayerList
            layers={animationData.layers}
            selectedLayerId={selectedLayerId}
            onSelectLayer={setSelectedLayerId}
          />
        </div>

        {/* Right: Preview */}
        <div className="right-panel">
          <Preview
            animationData={animationData}
            startTime={previewStartTime}
            isPlaying={isPlaying}
            onPlay={handlePlay}
            onPause={handlePause}
          />
        </div>
      </div>
    </div>
  );
};

export default App;