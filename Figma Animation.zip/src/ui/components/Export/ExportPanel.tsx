import React from 'react';
import type { FrameAnimationData } from '../../../core/types';
import './ExportPanel.css';

interface ExportPanelProps {
  animationData: FrameAnimationData;
  onExport: () => void;
}

export const ExportPanel: React.FC<ExportPanelProps> = ({ animationData, onExport }) => {
  return (
    <div style={{ padding: 10 }}>
      <h3 style={{ fontSize: 12, marginBottom: 10, textTransform: 'uppercase' }}>Export</h3>
      <div style={{ marginBottom: 10 }}>
        <div>Layers: {animationData.layers.length}</div>
        <div>Duration: {animationData.timeline.duration}s</div>
      </div>
      <button onClick={onExport} style={{ width: '100%', padding: 8 }}>
        Export HTML
      </button>
    </div>
  );
};