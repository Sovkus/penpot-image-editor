import React from 'react';
import type { FrameAnimationData } from '../../../core/types';
import './Preview.css';

interface PreviewProps {
  animationData: FrameAnimationData;
  startTime: number;
  isPlaying: boolean;
  onPlay: () => void;
  onPause: () => void;
}

export const Preview: React.FC<PreviewProps> = ({ animationData }) => {
  const { frameName, layers } = animationData;
  const firstLayer = layers[0];
  const width = firstLayer?.position.width || 300;
  const height = firstLayer?.position.height || 250;

  // Масштабируем до 350px максимум
  const maxSize = 320;
  const scale = Math.min(maxSize / width, maxSize / height, 1);

  return (
    <div className="preview">
      <div className="preview-header">
        <span className="preview-title">Preview</span>
        <span className="preview-dimensions">
          {Math.round(width)}×{Math.round(height)}
        </span>
      </div>
      <div className="preview-canvas">
        <div 
          className="preview-frame"
          style={{
            width: width * scale,
            height: height * scale,
          }}
        >
          {layers.map(layer => (
            <div
              key={layer.nodeId}
              className="preview-layer"
              style={{
                position: 'absolute',
                left: (layer.position.x / width) * 100 + '%',
                top: (layer.position.y / height) * 100 + '%',
                width: (layer.position.width / width) * 100 + '%',
                height: (layer.position.height / height) * 100 + '%',
                background: `hsl(${(layer.nodeId.charCodeAt(0) * 50) % 360}, 60%, 70%)`,
                opacity: layer.opacity,
                zIndex: layer.zIndex,
              }}
            />
          ))}
          <div className="preview-label">{frameName}</div>
        </div>
      </div>
    </div>
  );
};