import React from 'react';
import type { LayerData } from '../../../core/types';
import './LayerList.css';

interface LayerListProps {
  layers: LayerData[];
  selectedLayerId: string | null;
  onSelectLayer: (layerId: string) => void;
}

export const LayerList: React.FC<LayerListProps> = ({ layers, selectedLayerId, onSelectLayer }) => {
  return (
    <div className="layer-list">
      <div className="layer-list-header">
        <span>Layers</span>
        <span className="layer-count">{layers.length}</span>
      </div>
      <div className="layer-list-content">
        {layers.map((layer) => (
          <div
            key={layer.nodeId}
            className={`layer-item ${selectedLayerId === layer.nodeId ? 'selected' : ''}`}
            onClick={() => onSelectLayer(layer.nodeId)}
          >
            <div className="layer-icon">{getLayerIcon(layer.type)}</div>
            <div className="layer-name">{layer.name}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

function getLayerIcon(type: LayerData['type']): string {
  const icons: Record<string, string> = {
    IMAGE: '🖼️', RECTANGLE: '▭', ELLIPSE: '○',
    VECTOR: '✏️', GROUP: '📁', FRAME: '📐',
    TEXT: 'T', OTHER: '•',
  };
  return icons[type] || '•';
}