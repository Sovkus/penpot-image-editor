import React from 'react';
import type { TimelineConfig, LayerData } from '../../../core/types';
import './Timeline.css';

interface TimelineProps {
  timeline: TimelineConfig;
  layers: LayerData[];
  selectedLayerId: string | null;
  onTimelineChange: (timeline: TimelineConfig) => void;
  onLayerAnimationChange: (layerId: string, animType: 'in' | 'out', config: any) => void;
  onScrubberChange: (time: number) => void;
  isPlaying: boolean;
  onPlay: () => void;
  onPause: () => void;
}

export const Timeline: React.FC<TimelineProps> = ({ timeline, onPlay, onPause, isPlaying }) => {
  return (
    <div className="timeline">
      <div className="timeline-toolbar">
        <div className="timeline-controls">
          <button className="btn-icon" onClick={isPlaying ? onPause : onPlay}>
            {isPlaying ? '⏸️' : '▶️'}
          </button>
          <span className="timeline-duration">{timeline.duration}s</span>
        </div>
        <div className="timeline-ruler">
          <div className="ruler-mark">0s</div>
          <div className="ruler-mark">1s</div>
          <div className="ruler-mark">2s</div>
          <div className="ruler-mark">3s</div>
          <div className="ruler-mark">4s</div>
          <div className="ruler-mark">5s</div>
        </div>
      </div>
      <div className="timeline-tracks">
        {/* Здесь будут дорожки анимаций */}
        <div className="timeline-placeholder">Timeline tracks will appear here</div>
      </div>
    </div>
  );
};