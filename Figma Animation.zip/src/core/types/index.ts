export type AnimationType = 
  | 'fadeIn' | 'fadeOut'
  | 'fadeInUp' | 'fadeOutUp'
  | 'fadeInDown' | 'fadeOutDown'
  | 'fadeInLeft' | 'fadeOutLeft'
  | 'fadeInRight' | 'fadeOutRight'
  | 'slideInUp' | 'slideOutUp'
  | 'slideInDown' | 'slideOutDown'
  | 'slideInLeft' | 'slideOutLeft'
  | 'slideInRight' | 'slideOutRight'
  | 'zoomIn' | 'zoomOut'
  | 'rotateIn' | 'rotateOut'
  | 'bounceIn' | 'bounceOut'
  | 'flipInX' | 'flipOutX'
  | 'flipInY' | 'flipOutY'
  | 'none';

export type EasingType = 
  | 'linear'
  | 'ease'
  | 'ease-in'
  | 'ease-out'
  | 'ease-in-out'
  | 'custom';

export type ExportFormat = 'png' | 'jpg' | 'svg';

export interface Position {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface AnimationConfig {
  type: AnimationType;
  delay: number;
  duration: number;
  easing: EasingType;
}

export interface LayerData {
  nodeId: string;
  name: string;
  type: 'IMAGE' | 'RECTANGLE' | 'ELLIPSE' | 'VECTOR' | 'GROUP' | 'FRAME' | 'TEXT' | 'OTHER';
  exportFormat: ExportFormat;
  position: Position;
  zIndex: number;
  opacity: number;
  visible: boolean;
  in?: AnimationConfig;
  out?: AnimationConfig;
}

export interface TimelineConfig {
  duration: number;
  loop: boolean;
}

export interface FrameAnimationData {
  version: string;
  frameId: string;
  frameName: string;
  timeline: TimelineConfig;
  layers: LayerData[];
}

export interface ExportAsset {
  nodeId: string;
  name: string;
  format: ExportFormat;
  bytes: Uint8Array;
}

export interface ExportResult {
  html: string;
  css: string;
  js: string;
  assets: ExportAsset[];
}

export type PluginMessage =
  | { type: 'init' }
  | { type: 'scan-frame'; frameId: string }
  | { type: 'save-animation'; data: FrameAnimationData }
  | { type: 'load-animation'; frameId: string }
  | { type: 'export-html'; data: FrameAnimationData }
  | { type: 'export-assets'; layerIds: string[]; format: ExportFormat }
  | { type: 'update-preview'; data: FrameAnimationData; startTime: number };

export type UIMessage =
  | { type: 'frame-scanned'; data: FrameAnimationData }
  | { type: 'animation-loaded'; data: FrameAnimationData | null }
  | { type: 'animation-saved'; success: boolean }
  | { type: 'export-ready'; result: ExportResult }
  | { type: 'assets-exported'; assets: ExportAsset[] }
  | { type: 'preview-html'; html: string }
  | { type: 'error'; message: string };