import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'path';

export default defineConfig({
  plugins: [react()],
  build: {
    emptyOutDir: true,
    target: 'es2020',
    minify: false,
    rollupOptions: {
      input: {
        plugin: resolve(__dirname, 'src/plugin/main.ts'),
      },
      output: {
        dir: 'dist',
        entryFileNames: '[name].js',
      },
    },
  },
});